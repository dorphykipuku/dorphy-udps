package com.example.rams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
