package com.example.rams.Service;

import com.example.rams.model.Utilisateur;

import java.util.List;

public interface UtiService {

    List<Utilisateur> UTILISATEUR_LIST();
}
